
# Advanced Linux Networking Lab

**Level**: Intermediate to Advanced  
**Duration**: 60-90 minutes  
**Environment**: Cloud Sandbox (single VM setup)

---

## Objective

Participants will:
1. Create and manage multiple network namespaces.
2. Configure VLANs and virtual interfaces.
3. Set up a VPN using WireGuard.
4. Implement policy-based routing.
5. Configure essential network services like DNS and DHCP.
6. Utilize advanced networking tools for monitoring and troubleshooting.

---

## Scenario

You are tasked with setting up a secure, multi-segment network environment within a single Linux VM. The environment will simulate the following segments:
- **External Network** (Internet-facing)
- **DMZ** (Hosting a web server)
- **Internal Network** (Hosting application servers and databases)
- **VPN Network** (Secure remote access)

---

## Lab Steps

### Step 1: Preparation

1. Log in to the cloud sandbox Linux VM.
2. Install necessary packages:
   ```bash
   sudo apt update && sudo apt install -y iproute2 vlan wireguard dnsmasq bind9 traceroute net-tools tcpdump
   ```

### Step 2: Create Network Namespaces

1. Create namespaces:
   ```bash
   sudo ip netns add external
   sudo ip netns add dmz
   sudo ip netns add internal
   sudo ip netns add vpn
   ```
2. Verify namespaces:
   ```bash
   ip netns list
   ```

### Step 3: Configure Virtual Ethernet Pairs

- Configure veth pairs between the namespaces and host.
- Assign IP addresses and default routes.

### Step 4: Set Up VLANs

1. Create VLAN interfaces for DMZ and Internal networks:
   ```bash
   sudo ip link add link host-dmz name host-dmz.100 type vlan id 100
   sudo ip link add link host-internal name host-internal.200 type vlan id 200
   ```

### Step 5: Set Up VPN with WireGuard

1. Generate keys and configure WireGuard in the VPN namespace.
2. Configure WireGuard on the host.

### Step 6: Configure Network Services

1. **DNS Server** (DMZ):
   ```bash
   sudo ip netns exec dmz systemctl start bind9
   ```
2. **DHCP Server** (Internal):
   ```bash
   sudo ip netns exec internal systemctl start dnsmasq
   ```

### Step 7: Policy-Based Routing

1. Define custom routing tables:
   ```bash
   echo "100 internal" | sudo tee -a /etc/iproute2/rt_tables
   ```

### Step 8: Troubleshooting

1. Use `tcpdump`, `traceroute`, and `dig` to analyze and resolve network issues.

### Cleanup

1. Remove namespaces, interfaces, and rules.

---

## Deliverables

- Configuration scripts.
- Troubleshooting logs.

---

## Outcome

Participants will gain practical experience in advanced Linux networking, including namespaces, VLANs, VPNs, policy-based routing, and network services.

---
