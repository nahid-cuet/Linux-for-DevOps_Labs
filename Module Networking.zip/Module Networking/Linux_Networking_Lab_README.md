
# Linux Networking Hands-On Lab

## Objective
This lab aims to provide hands-on experience in configuring and troubleshooting Linux networking, including firewall rules, routing, and DNS. 

## Duration
50-60 minutes

## Prerequisites
- Basic understanding of Linux command-line operations
- Access to a cloud sandbox environment with a single Linux VM
- Tools installed: `iptables`, `ping`, `dig`, `traceroute`

---

## Lab Instructions

### Step 1: Basic Network Checks
1. Check the server’s IP address and network configuration:
   ```bash
   ip addr show
   ip route show
   ```

2. Verify DNS configuration:
   ```bash
   cat /etc/resolv.conf
   ```

3. Test DNS resolution:
   ```bash
   dig google.com
   ```

4. Check connectivity to the default gateway:
   ```bash
   ping -c 4 <gateway_IP>
   ```

---

### Step 2: Set Up and Test Firewall Rules
1. Flush existing rules and configure default policies:
   ```bash
   sudo iptables -F
   sudo iptables -P INPUT DROP
   sudo iptables -P FORWARD DROP
   sudo iptables -P OUTPUT ACCEPT
   ```

2. Add rules to:
   - Allow HTTP traffic from any source:
     ```bash
     sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT
     ```
   - Restrict SSH traffic to internal IPs (e.g., `192.168.1.0/24`):
     ```bash
     sudo iptables -A INPUT -p tcp -s 192.168.1.0/24 --dport 22 -j ACCEPT
     ```
   - Allow loopback traffic:
     ```bash
     sudo iptables -A INPUT -i lo -j ACCEPT
     ```

3. Save and verify the configuration:
   ```bash
   sudo iptables-save
   sudo iptables -L -v
   ```

4. Test connectivity:
   - Use `curl` to test HTTP access:
     ```bash
     curl http://127.0.0.1
     ```
   - Test SSH access from allowed and restricted IPs.

---

### Step 3: Analyze ARP and Routing Tables
1. View the ARP table:
   ```bash
   ip neigh show
   ```

2. Analyze the routing table:
   ```bash
   ip route show
   ```

3. Add a static route:
   ```bash
   sudo ip route add 10.0.0.0/24 via <alternate_gateway_IP>
   ```

4. Test the static route:
   ```bash
   ping -c 4 <IP_in_10.0.0.0/24>
   ```

---

### Step 4: Advanced Connectivity Tests
1. Trace the route to an external server:
   ```bash
   traceroute google.com
   ```

2. Simulate and resolve DNS issues:
   - Remove a DNS server entry in `/etc/resolv.conf`.
   - Test the impact using `dig`.
   - Restore the entry and re-test.

---

### Step 5: Troubleshooting Exercise
**Problem:** The web server is unreachable from external clients.

1. Simulate the issue by adding a blocking rule:
   ```bash
   sudo iptables -I INPUT 1 -p tcp --dport 80 -j DROP
   ```

2. Diagnose the issue:
   - Use `iptables -L -v` to inspect firewall rules.
   - Use `curl` or `ping` to test connectivity.

3. Resolve the issue by removing the blocking rule:
   ```bash
   sudo iptables -D INPUT -p tcp --dport 80 -j DROP
   ```

4. Verify connectivity is restored.

---

### Cleanup
1. Flush firewall rules and restore default policies:
   ```bash
   sudo iptables -F
   sudo iptables -P INPUT ACCEPT
   sudo iptables -P FORWARD ACCEPT
   sudo iptables -P OUTPUT ACCEPT
   ```

2. Remove any static routes:
   ```bash
   sudo ip route del 10.0.0.0/24
   ```

---

## Outcome
Participants will learn to:
1. Configure Linux firewall rules.
2. Analyze and troubleshoot network configurations.
3. Use essential networking tools to diagnose real-world issues.

