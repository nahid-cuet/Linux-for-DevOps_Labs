
# Simplified Networking in Linux Lab

**Level**: Beginner to Intermediate  
**Duration**: 30-45 minutes  
**Environment**: Single Linux VM (cloud or local)

---

## Objective

This lab focuses on hands-on practice for:  
- Configuring IP addresses and routes.  
- Managing DNS settings.  
- Using basic networking tools like `ping`, `traceroute`, and `tcpdump`.  
- Setting up and testing namespaces.  

---

## Lab Steps

### Step 1: Configure IP Address and Gateway

1. View current IP configuration:  
   ```bash
   ip addr show
   ```  

2. Assign a static IP to an interface:  
   ```bash
   sudo ip addr add 192.168.1.10/24 dev eth0
   ```  

3. Set a default gateway:  
   ```bash
   sudo ip route add default via 192.168.1.1
   ```  

4. Verify configuration:  
   ```bash
   ip addr show dev eth0
   ip route show
   ```  

---

### Step 2: Configure DNS

1. Edit the DNS resolver file:  
   ```bash
   sudo nano /etc/resolv.conf
   ```  

2. Add a nameserver:  
   ```bash
   nameserver 8.8.8.8
   ```  

3. Test DNS resolution:  
   ```bash
   ping www.google.com
   ```  

---

### Step 3: Test and Troubleshoot the Network

1. Ping a remote server:  
   ```bash
   ping -c 4 8.8.8.8
   ```  

2. Trace the route to a server:  
   ```bash
   traceroute 8.8.8.8
   ```  

3. Analyze ARP table:  
   ```bash
   ip neigh show
   ```  

4. Capture network traffic:  
   ```bash
   sudo tcpdump -i eth0 port 80
   ```  

---

### Step 4: Create and Test a Network Namespace

1. Create a new namespace:  
   ```bash
   sudo ip netns add test_ns
   ```  

2. Create a virtual Ethernet pair:  
   ```bash
   sudo ip link add veth0 type veth peer name veth1
   ```  

3. Assign one end to the namespace:  
   ```bash
   sudo ip link set veth1 netns test_ns
   ```  

4. Assign IPs:  
   On the host:  
   ```bash
   sudo ip addr add 10.0.0.1/24 dev veth0
   sudo ip link set veth0 up
   ```  
   In the namespace:  
   ```bash
   sudo ip netns exec test_ns ip addr add 10.0.0.2/24 dev veth1
   sudo ip netns exec test_ns ip link set veth1 up
   ```  

5. Test connectivity:  
   ```bash
   sudo ip netns exec test_ns ping -c 4 10.0.0.1
   ```  

---

### Step 5: Cleanup

1. Delete the namespace:  
   ```bash
   sudo ip netns del test_ns
   ```  

2. Remove the virtual Ethernet pair:  
   ```bash
   sudo ip link delete veth0
   ```  

---

## Outcome

Participants will learn how to:  
- Configure basic IP settings.  
- Manage DNS for network resolution.  
- Use Linux tools for troubleshooting.  
- Set up namespaces to isolate network environments.  
