
# Linux Security Hands-On Lab: OS Hardening and Secure Application Deployment

**Difficulty Level:** 7/8  
**Duration:** 40-60 minutes  
**Objective:** Practice Linux security best practices by hardening a Linux operating system and deploying an application securely. This lab mirrors real-world security tasks, helping participants tackle common job-field security issues.

---

## Scenario:
You are hired as a Linux system administrator in an e-commerce company. The company’s web application is vulnerable to external threats, and your job is to harden the Linux operating system running the web application and securely deploy it to minimize exposure to risks.

**Goal:** Secure the OS by hardening its configuration, enforcing access controls, and securely deploying a web application with encryption and monitoring to prevent attacks.

---

## Lab Setup:
You will need a Linux machine (either a local VM or a cloud server) with **root** or **sudo** privileges.  
**Prerequisites:**
- Basic Linux command-line experience
- Familiarity with installing and configuring software on Linux (e.g., Nginx)

---

## Lab Outline:

1. **Task 1: Basic OS Hardening**
   - **Disable unnecessary services** to reduce the attack surface.
   - **Secure SSH** by restricting root login and configuring key-based authentication.
   - **Configure a firewall** to allow only necessary traffic.

2. **Task 2: Secure Web Application Deployment**
   - Deploy a **secure Nginx** web server.
   - Set up **SSL encryption** using Let’s Encrypt.
   - Harden web server configuration by enforcing **strong file permissions** and disabling directory listing.

3. **Task 3: Implement System Monitoring and Auditing**
   - Set up **Fail2ban** to prevent brute-force attacks.
   - Use **auditd** to monitor changes to critical files.

---

## Step-by-Step Instructions:

---

### **Task 1: Basic OS Hardening**

#### **Step 1.1: Disable Unnecessary Services**
Unnecessary services increase the risk of exploitation.

1. **List all running services:**
   ```bash
   sudo systemctl list-units --type=service
   ```

2. **Stop and disable services that are not required for your system:**
   ```bash
   sudo systemctl stop avahi-daemon
   sudo systemctl disable avahi-daemon
   ```
   (Repeat for other services like `cups`, `bluetooth`, etc.)

3. **Check for open ports:**
   ```bash
   sudo netstat -tuln
   ```

#### **Step 1.2: Secure SSH**
SSH is a common entry point for attackers, so it’s essential to lock it down.

1. **Edit the SSH configuration file:**
   ```bash
   sudo nano /etc/ssh/sshd_config
   ```

2. **Disable root login:**
   ```bash
   PermitRootLogin no
   ```

3. **Disable password authentication and require key-based authentication:**
   ```bash
   PasswordAuthentication no
   ```

4. **Change the default SSH port (optional):**
   ```bash
   Port 2222
   ```

5. **Restart the SSH service:**
   ```bash
   sudo systemctl restart sshd
   ```

#### **Step 1.3: Configure a Firewall**
Setting up a firewall helps control traffic to your server.

1. **Install and configure UFW (for Ubuntu):**
   ```bash
   sudo apt update
   sudo apt install ufw
   sudo ufw allow 2222/tcp  # SSH
   sudo ufw allow 80/tcp    # HTTP
   sudo ufw allow 443/tcp   # HTTPS
   sudo ufw enable
   ```

   Or for **CentOS** (firewalld):
   ```bash
   sudo firewall-cmd --permanent --add-port=2222/tcp
   sudo firewall-cmd --permanent --add-service=http
   sudo firewall-cmd --permanent --add-service=https
   sudo firewall-cmd --reload
   ```

---

### **Task 2: Secure Web Application Deployment**

#### **Step 2.1: Install and Configure Nginx**
Deploying the Nginx web server with strong security measures.

1. **Install Nginx:**
   ```bash
   sudo apt install nginx  # For Ubuntu/Debian
   ```

2. **Create a non-root user** for running the web server (e.g., `webappuser`) and set ownership of the web root directory:
   ```bash
   sudo useradd -r -s /bin/false webappuser
   sudo chown -R webappuser:webappuser /var/www/html
   ```

3. **Set proper permissions** for the web directory:
   ```bash
   sudo chmod -R 755 /var/www/html
   ```

4. **Disable directory listing** by editing `/etc/nginx/nginx.conf`:
   ```bash
   autoindex off;
   ```

5. **Restart Nginx:**
   ```bash
   sudo systemctl restart nginx
   ```

#### **Step 2.2: Enable SSL Encryption**
Encrypt traffic using Let’s Encrypt for free SSL certificates.

1. **Install Certbot:**
   ```bash
   sudo apt install certbot python3-certbot-nginx
   ```

2. **Request an SSL certificate:**
   ```bash
   sudo certbot --nginx
   ```

3. **Test SSL configuration:**
   ```bash
   sudo nginx -t
   ```

4. **Renew SSL certificates automatically:**
   ```bash
   sudo certbot renew --dry-run
   ```

---

### **Task 3: System Monitoring and Auditing**

#### **Step 3.1: Install Fail2ban**
Protect against brute-force attacks by blocking malicious IPs after several failed login attempts.

1. **Install Fail2ban:**
   ```bash
   sudo apt install fail2ban
   ```

2. **Configure Fail2ban for SSH protection:**
   Edit the `/etc/fail2ban/jail.local` file and configure it as follows:
   ```ini
   [sshd]
   enabled = true
   port = 2222
   logpath = /var/log/auth.log
   maxretry = 3
   ```

3. **Restart Fail2ban:**
   ```bash
   sudo systemctl restart fail2ban
   ```

4. **Monitor Fail2ban logs:**
   ```bash
   sudo tail -f /var/log/fail2ban.log
   ```

#### **Step 3.2: Set Up auditd for File Auditing**
Audit critical files like SSH configurations to detect unauthorized changes.

1. **Install auditd:**
   ```bash
   sudo apt install auditd
   sudo systemctl start auditd
   ```

2. **Set up an audit rule** to monitor changes to `/etc/ssh/sshd_config`:
   ```bash
   sudo auditctl -w /etc/ssh/sshd_config -p wa -k sshd_changes
   ```

3. **Check audit logs** for changes:
   ```bash
   sudo ausearch -k sshd_changes
   ```

---

## Lab Wrap-Up:

In this lab, you have:
- Hardened the Linux OS by disabling unnecessary services, securing SSH, and configuring a firewall.
- Deployed a web application securely with Nginx, enforcing SSL encryption and access control.
- Set up monitoring and auditing tools like Fail2ban and auditd to prevent unauthorized access and log critical events.

These practices are essential in real-world Linux administration, where security is critical to protecting systems and applications from attacks.

