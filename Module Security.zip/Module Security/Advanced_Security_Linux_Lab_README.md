
# Advanced Linux Security Hands-On Lab: Incident Response and Forensic Investigation

**Difficulty Level:** 8/10  
**Duration:** 40-50 minutes  
**Objective:** Conduct an incident response and forensic investigation on a compromised Linux server, applying advanced security practices to detect, analyze, and remediate the attack. The goal is to simulate a real-world scenario in which an attacker has compromised the server and left traces that need to be identified and handled.

---

## Scenario:

You are the system administrator for a medium-sized tech company. Your monitoring system has flagged unusual behavior on a critical server. Logs show unauthorized login attempts, possible file modifications, and suspicious outgoing traffic. Your task is to investigate the server, detect any intrusions, and secure the system to prevent future attacks. You will identify the attacker’s steps, reverse malicious changes, and harden the system.

---

## Lab Setup:

You will need access to a Linux machine (VM or cloud server) with **root** or **sudo** privileges. The machine should have standard monitoring and logging tools available (e.g., `auditd`, `sshd`, and system logs).

---

## Lab Outline:

1. **Task 1: Analyze Login Activity and Unusual Access**
   - Investigate the compromised system to identify unauthorized login attempts.
   - Review `auth.log` or equivalent for suspicious logins.
   - Identify and isolate malicious user accounts.

2. **Task 2: Analyze System for Rootkits and Backdoors**
   - Use tools like `chkrootkit` or `rkhunter` to check for rootkits or hidden malware.
   - Analyze modifications to key system files.

3. **Task 3: Investigate Suspicious Network Traffic**
   - Analyze network traffic to detect outgoing communications to suspicious IP addresses.
   - Use tools like `netstat`, `ss`, and `tcpdump` to monitor traffic and open connections.

4. **Task 4: Secure the System and Remediate the Attack**
   - Remove unauthorized accounts and secure SSH.
   - Block suspicious IP addresses using firewall rules.
   - Patch vulnerabilities to prevent future attacks.

5. **Task 5: Set up System Monitoring and Logging**
   - Configure enhanced logging and monitoring to detect future intrusions.
   - Set up tools like `fail2ban`, `auditd`, and system log monitoring.

---

## Step-by-Step Instructions:

---

### **Task 1: Analyze Login Activity and Unusual Access**

#### **Step 1.1: Investigate Login Attempts**
Check system logs for unauthorized access attempts:

1. **View SSH login attempts in the authentication log**:
   ```bash
   sudo cat /var/log/auth.log | grep "sshd"
   ```

2. **Check for repeated failed login attempts, which might indicate a brute-force attack:**
   ```bash
   sudo cat /var/log/auth.log | grep "Failed password"
   ```

3. **Look for logins from unusual IP addresses:**
   ```bash
   sudo cat /var/log/auth.log | grep "Accepted"
   ```

4. **Identify any unauthorized users created:**
   ```bash
   sudo cat /etc/passwd
   ```

#### **Step 1.2: Isolate Malicious Users**
If an unauthorized user is found, remove or disable their account:

1. **Disable suspicious user accounts:**
   ```bash
   sudo usermod -L <username>
   ```

2. **Check for users with sudo privileges:**
   ```bash
   sudo cat /etc/sudoers
   ```

---

### **Task 2: Analyze System for Rootkits and Backdoors**

#### **Step 2.1: Check for Rootkits**

Install and run rootkit detection tools:

1. **Install `chkrootkit`:**
   ```bash
   sudo apt install chkrootkit
   ```

2. **Run the rootkit scan:**
   ```bash
   sudo chkrootkit
   ```

3. **Install and run `rkhunter`:**
   ```bash
   sudo apt install rkhunter
   sudo rkhunter --check
   ```

#### **Step 2.2: Analyze Key System Files**
Check for unauthorized modifications to key system binaries:

1. **Compare file integrity using checksums (e.g., `sha256sum`):**
   ```bash
   sha256sum /bin/ls
   ```

2. **Search for altered files in `/etc` or system-critical directories:**
   ```bash
   sudo find /etc -type f -exec stat {} \; | grep Change
   ```

---

### **Task 3: Investigate Suspicious Network Traffic**

#### **Step 3.1: Check Network Connections**
Monitor open connections for suspicious activity:

1. **List all open network connections:**
   ```bash
   sudo netstat -tuln
   ```

2. **Look for unusual connections (high port numbers or foreign IPs):**
   ```bash
   sudo ss -antp
   ```

#### **Step 3.2: Capture Traffic for Further Analysis**
Use `tcpdump` to monitor network traffic:

1. **Install `tcpdump`:**
   ```bash
   sudo apt install tcpdump
   ```

2. **Capture traffic on a specific interface (e.g., eth0):**
   ```bash
   sudo tcpdump -i eth0
   ```

3. **Save traffic to a file for further analysis:**
   ```bash
   sudo tcpdump -i eth0 -w suspicious_traffic.pcap
   ```

---

### **Task 4: Secure the System and Remediate the Attack**

#### **Step 4.1: Remove Unauthorized Access**
Remove unauthorized accounts and tighten SSH configuration:

1. **Delete suspicious users:**
   ```bash
   sudo deluser <username>
   ```

2. **Secure SSH by editing `/etc/ssh/sshd_config`:**
   ```bash
   PermitRootLogin no
   PasswordAuthentication no
   ```

#### **Step 4.2: Block Malicious IPs**
Block any suspicious IPs identified earlier:

1. **Block IPs using UFW (Ubuntu):**
   ```bash
   sudo ufw deny from <malicious_IP>
   ```

2. **Restart firewall services:**
   ```bash
   sudo systemctl restart ufw
   ```

#### **Step 4.3: Patch Vulnerabilities**
Update the system to fix any security vulnerabilities:

1. **Update and upgrade all installed packages:**
   ```bash
   sudo apt update && sudo apt upgrade -y
   ```

---

### **Task 5: Set up System Monitoring and Logging**

#### **Step 5.1: Install Fail2ban**
Install Fail2ban to monitor and block brute-force attacks:

1. **Install Fail2ban:**
   ```bash
   sudo apt install fail2ban
   ```

2. **Enable SSH protection in Fail2ban by editing `/etc/fail2ban/jail.local`:**
   ```bash
   [sshd]
   enabled = true
   port = 22
   maxretry = 3
   logpath = /var/log/auth.log
   ```

3. **Restart Fail2ban:**
   ```bash
   sudo systemctl restart fail2ban
   ```

#### **Step 5.2: Set Up Auditd for File Monitoring**
Use `auditd` to track changes to critical files:

1. **Install auditd:**
   ```bash
   sudo apt install auditd
   ```

2. **Monitor changes to critical files (e.g., `/etc/passwd`):**
   ```bash
   sudo auditctl -w /etc/passwd -p wa -k passwd_changes
   ```

3. **Check audit logs for changes:**
   ```bash
   sudo ausearch -k passwd_changes
   ```

---

### Lab Wrap-Up:

In this advanced lab, you learned how to:
- Investigate a compromised Linux system by checking login activity, network connections, and file integrity.
- Detect and remove rootkits and backdoors.
- Secure the system by removing unauthorized access, tightening security controls, and patching vulnerabilities.
- Set up advanced monitoring and logging to prevent future attacks.

These practices are critical for real-world Linux security, especially in incident response and forensic investigations.
