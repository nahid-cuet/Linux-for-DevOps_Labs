
# Managing Permissions and Ownership in a Collaborative Environment

## Scenario:
You have been hired as a system administrator for a small company. The company has different departments, each requiring specific access to their files. You need to set up the file permissions and ownership to ensure security and proper access control. The company has the following departments:
- **HR**
- **Finance**
- **Engineering**

Each department has its own directory, and only members of the respective department should have access to their files. Additionally, you need to set up special permissions for certain files and directories.

## Lab Objectives:
By the end of this lab, students will be able to:
1. Understand and change user and group ownership.
2. Modify file and directory permissions.
3. Implement special permissions like sticky bit, setgid, and setuid.
4. Apply real-world knowledge of permissions to manage a collaborative environment.

## Lab Duration:
Approximately 2 hours

## Prerequisites:
Basic knowledge of Linux commands and navigation.

## Resources:
- Virtual Machine with a Linux distribution (e.g., Ubuntu)
- Terminal access

## Lab Steps:

### Step 1: Set Up the Environment
1. **Create Department Groups:**
    ```bash
    sudo groupadd hr
    sudo groupadd finance
    sudo groupadd engineering
    ```

2. **Create Department Users and Add to Groups:**
    ```bash
    sudo useradd -m -G hr alice
    sudo useradd -m -G finance bob
    sudo useradd -m -G engineering charlie
    ```

3. **Create Department Directories:**
    ```bash
    sudo mkdir /company
    sudo mkdir /company/hr
    sudo mkdir /company/finance
    sudo mkdir /company/engineering
    ```

4. **Set Ownership and Permissions:**
    ```bash
    sudo chown :hr /company/hr
    sudo chown :finance /company/finance
    sudo chown :engineering /company/engineering
    
    sudo chmod 770 /company/hr
    sudo chmod 770 /company/finance
    sudo chmod 770 /company/engineering
    ```

### Step 2: Modify File and Directory Permissions
1. **Create Files for Testing:**
    ```bash
    sudo touch /company/hr/confidential.txt
    sudo touch /company/finance/budget.txt
    sudo touch /company/engineering/design.txt
    ```

2. **Set Specific File Permissions:**
    ```bash
    sudo chmod 640 /company/hr/confidential.txt
    sudo chmod 660 /company/finance/budget.txt
    sudo chmod 644 /company/engineering/design.txt
    ```

### Step 3: Implement Special Permissions
1. **Set Sticky Bit on a Shared Directory:**
    ```bash
    sudo mkdir /company/shared
    sudo chmod 1777 /company/shared
    ```

2. **Set SetGID on a Department Directory:**
    ```bash
    sudo chmod 2770 /company/engineering
    ```

3. **Set SetUID on a Specific File:**
    ```bash
    sudo touch /company/engineering/runme
    sudo chmod 4755 /company/engineering/runme
    ```

### Step 4: Verification
1. **Verify Ownership and Permissions:**
    ```bash
    ls -l /company/hr
    ls -l /company/finance
    ls -l /company/engineering
    ls -l /company/shared
    ```

2. **Test Access with Different Users:**
    ```bash
    su - alice
    cat /company/hr/confidential.txt
    cat /company/finance/budget.txt (should fail)
    
    su - bob
    cat /company/finance/budget.txt
    cat /company/engineering/design.txt (should fail)
    
    su - charlie
    cat /company/engineering/design.txt
    echo "new design" > /company/engineering/design.txt
    ```

## Conclusion:
This lab helps students understand how to manage file and directory permissions and ownership in a multi-user environment, ensuring that security and access control are maintained according to organizational needs.
