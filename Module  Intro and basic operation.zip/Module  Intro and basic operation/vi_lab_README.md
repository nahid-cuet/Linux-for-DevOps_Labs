
# Hands-On Lab: Mastering the `vi` Editor

## **Introduction**
This lab introduces you to the `vi` editor, a powerful text editor in Linux. The lab is divided into three parts, focusing on navigating, editing, and using additional features of the editor.

### **Lab Prerequisites**
1. A Linux system (physical, virtual, or cloud-based).
2. Basic knowledge of the Linux file system and command-line operations.

---

## **Part 1: Navigation and Insertion**
### **Objective**
Learn how to navigate through a file and insert new content using the `vi` editor.

### **Steps**
1. **Create a sample file:**
   ```bash
   cat > server_config.txt <<EOL
   # Server Configuration File
   # Created: 2024-11-29
   # Author: Admin

   SERVER_NAME=localhost
   IP_ADDRESS=127.0.0.1
   PORT=8080
   TIMEOUT=30
   EOL
   ```

2. **Open the file in `vi`:**
   ```bash
   vi server_config.txt
   ```

3. **Navigate within the file:**
   - Use `h`, `j`, `k`, `l` to move left, down, up, and right.
   - Use `Ctrl-d` and `Ctrl-u` to scroll down and up.

4. **Insert new content:**
   - Move to the end of the file using `G`.
   - Press `o` to open a new line below the current one and type:
     ```bash
     BACKUP_ENABLED=true
     ```
   - Press `Esc` to exit insert mode.

5. **Save and exit the file:**
   - Press `:wq` and hit `Enter`.

---

## **Part 2: Search and Replace**
### **Objective**
Learn how to find and replace strings within a file using the `vi` editor.

### **Steps**
1. **Open the file:**
   ```bash
   vi server_config.txt
   ```

2. **Find a string:**
   - Press `/` and type the string you want to find (e.g., `localhost`) and press `Enter`.
   - Use `n` to move to the next occurrence.

3. **Replace a string:**
   - To replace the first occurrence of `localhost` with `webserver.local`, type:
     ```bash
     :s/localhost/webserver.local/
     ```
   - To replace all occurrences in the file, type:
     ```bash
     :%s/localhost/webserver.local/g
     ```

4. **Save and exit:**
   - Press `:wq` and hit `Enter`.

---

## **Part 3: Advanced Options**
### **Objective**
Explore additional `vi` editor features like enabling line numbers, deleting lines, and undoing changes.

### **Steps**
1. **Enable line numbers:**
   - In `vi`, type:
     ```bash
     :set nu
     ```

2. **Delete a whole line:**
   - Navigate to the line you want to delete and press `dd`.

3. **Undo changes:**
   - Press `u` to undo the last change.

4. **Save and exit:**
   - Press `:wq` and hit `Enter`.

---

## **Expected Output**
After completing all parts, the `server_config.txt` file should look like this:
```
# Server Configuration File
# Created: 2024-11-29
# Author: Admin

SERVER_NAME=webserver.local
IP_ADDRESS=127.0.0.1
PORT=8080
TIMEOUT=30
BACKUP_ENABLED=true
```

---

## **Additional Challenge**
1. **Search and Replace:** Replace all occurrences of `127.0.0.1` with `192.168.1.1`.
   ```bash
   :%s/127.0.0.1/192.168.1.1/g
   ```

2. **Exit without saving changes:**
   ```bash
   :q!
   ```

Happy Learning!
